<?php

namespace Tests;

use PHPUnit\Framework\TestCase;

class NullTest extends TestCase
{

    public function setUp() 
    {
    }


    /** @test */
    public function it_null()
    {
        $this->assertNull(null);
    }

}
