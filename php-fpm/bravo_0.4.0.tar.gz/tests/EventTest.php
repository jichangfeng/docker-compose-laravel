<?php

namespace Tests;

use PHPUnit\Framework\TestCase;

use Bravo\Events\Event;
use Bravo\Events\Manager;


class EventTest extends TestCase
{

    protected $listener;
    protected $manager;


    public function setUp() 
    {
        $this->manager = new Manager();

        require_once("FirstListener.php");

        $this->manager->attach('log', new FirstListener());

    }

    /** @test */
    public function testManager()
    {

        $this->assertCount(1, $this->manager->getListeners('log'));
        
    }

    /** @test */
    public function testFire()
    {

        $status = $this->manager->fire('log:log', $this, "Hello");

        // test event result
        $this->assertEquals($status, 'Hello');

        
    }

}
