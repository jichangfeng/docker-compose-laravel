<?php

namespace Tests;

use PHPUnit\Framework\TestCase;

use Bravo\Di;


class DiTest extends TestCase
{

    public function setUp() 
    {
        $this->container = new Di();
        $this->container->setShared('test1', function(){
            return new \StdClass();
        });
        $this->container->set('test2', function(){
            return new \StdClass();
        });

        require_once('TestClass1.php');
        $this->container->set('class1', "\\Tests\\TestClass1");
    }


    /** @test */
    public function testShared()
    {
        $i1 = $this->container->get('test1');
        $i2 = $this->container->get('test1');
        
        $this->assertSame($i1, $i2);
    }


    /** @test */
    public function testShared2()
    {
        $i1 = $this->container->get('test2');
        $i2 = $this->container->get('test2');
        
        $this->assertNotSame($i1, $i2);
    }

    /** @test */
    public function testClassLoader()
    {
        $i1 = $this->container->get('class1');
        
        $this->assertEquals($i1->hi(), "Hello");
    }


}
