<?php

namespace Tests;

use PHPUnit\Framework\TestCase;

use Bravo\Translate\Adapter\NativeArray;


class TranslateTest extends TestCase
{

    public function setUp() 
    {
        $this->lang = array(
            'en' => array(
                'hi'        => 'Hello',
                'bye'       => 'Good Bye',
                'hello-key' => 'Hello %name%',
                'song-key'  => 'This song is %song% (%artist%)',
            ),
            'es' => array (
                'hi'        => 'Hola',
                'bye'       => 'Adiós',
                'hello-key' => 'Hola %name%',
                'song-key'  => 'La canción es %song% (%artist%)',
            )
        );

    }


    /** @test */
    public function testEnglish()
    {
        $expect = "Hello";
        $t = new NativeArray(array('content'=>$this->lang["en"]));

        $this->assertEquals($t->_('hi'), $expect);
    }

    /** @test */
    public function testEnglishDefault()
    {
        $expect = "World";
        $t = new NativeArray(array('content'=>$this->lang["en"]));

        $this->assertEquals($t->_('World'), $expect);
    }

    /** @test */
    public function testEnglishKey()
    {
        $expect = "Hello Rack";
        $t = new NativeArray(array('content'=>$this->lang["en"]));

        $this->assertEquals($t->_('hello-key', array('name'=>"Rack")), $expect);
    }

    /** @test */
    public function testSpanish()
    {
        $expect = "Hola";
        $t = new NativeArray(array('content'=>$this->lang["es"]));

        $this->assertEquals($t->_('hi'), $expect);
    }

    /** @test */
    public function testAppJsonResource()
    {
        $langDir = dirname(__FILE__) . DIRECTORY_SEPARATOR . "app_lang" . DIRECTORY_SEPARATOR ;

        $messages = \Bravo\Locale::loadJsonResource("zh-CN", $langDir);

        $expect = "您好! %name% .";
        $this->assertEquals($expect, $messages['hello']);
    }


    /** @test */
    public function testAppJsonResourceFallback()
    {
        $langDir = dirname(__FILE__) . DIRECTORY_SEPARATOR . "app_lang" . DIRECTORY_SEPARATOR ;

        $messages = \Bravo\Locale::loadJsonResource("jp-JP", $langDir);

        $expect = "Hi! %name% .";
        $this->assertEquals($expect, $messages['hello']);
    }

    /** @test */
    public function testOptionalJsonResource()
    {
        $langDir = dirname(__FILE__) . DIRECTORY_SEPARATOR . "app_lang" . DIRECTORY_SEPARATOR ;
        $optDir = dirname(__FILE__) . DIRECTORY_SEPARATOR . "optional_lang" . DIRECTORY_SEPARATOR ;

        $messages = \Bravo\Locale::loadJsonResource("zh-CN", $langDir, $optDir);

        $expect = "亲！您好! %name% .";
        $this->assertEquals($expect, $messages['hello']);
    }

    
}
