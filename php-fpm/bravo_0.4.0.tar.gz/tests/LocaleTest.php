<?php

namespace Tests;

use PHPUnit\Framework\TestCase;

class LocaleTest extends TestCase
{

    public function setUp() 
    {
        $_SERVER["HTTP_ACCEPT_LANGUAGE"] = "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7";
    }


    /** @test */
    public function testLocaleCount()
    {
        $this->assertCount(4, \Bravo\Locale::getLanguages());
    }

    /** @test */
    public function testLocale()
    {
        $this->assertEquals("zh-CN", \Bravo\Locale::getBestLanguage());
    }

}
