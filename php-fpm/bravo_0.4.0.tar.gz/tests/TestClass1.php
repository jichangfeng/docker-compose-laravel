<?php

namespace Tests;

class TestClass1
{

    public function hi() {
        return "Hello";
    }

}
