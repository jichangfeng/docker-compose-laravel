<?php

namespace Tests;

class FirstListener
{

    public function log($event, $c, $data) {
        $c->assertEquals($data, 'Hello');
        return "Hello";
    }
}
