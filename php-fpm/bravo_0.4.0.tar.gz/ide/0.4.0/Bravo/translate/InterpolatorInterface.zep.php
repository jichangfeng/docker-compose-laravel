<?php

namespace Bravo\Translate;

/**
 * Bravo\Translate\AdapterInterface
 *
 * Interface for Bravo\Translate adapters
 */
interface InterpolatorInterface
{

    /**
     * Replaces placeholders by the values passed
     *
     * @param string $translation
     * @param mixed $placeholders
     * @return string
     */
    public function replacePlaceholders(string $translation, $placeholders = null): string;

}
