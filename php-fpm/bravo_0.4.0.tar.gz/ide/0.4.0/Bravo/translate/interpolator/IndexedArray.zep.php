<?php

namespace Bravo\Translate\Interpolator;


class IndexedArray implements \Bravo\Translate\InterpolatorInterface
{

    /**
     * Replaces placeholders by the values passed
     *
     * @param string $translation
     * @param mixed $placeholders
     * @return string
     */
    public function replacePlaceholders(string $translation, $placeholders = null): string {}

}
