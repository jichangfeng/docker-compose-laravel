<?php

namespace Bravo\Translate;

/**
 * Bravo\Translate\Exception
 *
 * Class for exceptions thrown by Bravo\Translate
 */
class Exception extends \Bravo\Exception
{

}
