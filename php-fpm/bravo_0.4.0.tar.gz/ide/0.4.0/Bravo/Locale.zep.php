<?php

namespace Bravo;

/**
 * Bravo\Locale
 *
 * Bravo\Locale is a component that implements Locale help utilities.
 */
class Locale
{

    /**
     * Gets languages array and their quality accepted by the browser/client from _SERVER["HTTP_ACCEPT_LANGUAGE"]
     *
     * @return array
     */
    public static function getLanguages(): array {}

    /**
     * Gets best language accepted by the browser/client from _SERVER["HTTP_ACCEPT_LANGUAGE"]
     *
     * @return string
     */
    public static function getBestLanguage(): string {}

    /**
     * load json files language resources from language directory
     *
     * @param string $locale
     * @param array $appLangDir
     * @param string $optionalLangDir
     * @return array
     */
    public static function loadJsonResource(string $locale, string $appLangDir, string $optionalLangDir = ''): array {}

    /**
     * load json files language resources from language directory
     *
     * @param string $localeDir
     * @param string $locale
     * @param array $appLangDir
     * @param string $optionalLangDir
     * @return array
     */
    protected static function _loadJsonFromLangDir(string $localeDir): array {}

    /**
     * Gets variable from $_SERVER superglobal
     *
     * @param string $name
     * @return string|null
     */
    protected final static function _getServer(string $name): ?string {}

    /**
     * Process a request header and return the one with best quality
     *
     * @param array $qualityParts
     * @param string $name
     * @return string
     */
    protected final static function _getBestQuality(array $qualityParts, string $name): string {}

    /**
     * Process a request header and return an array of values with their qualities
     *
     * @param string $serverIndex
     * @param string $name
     * @return array
     */
    protected final static function _getQualityHeader(string $serverIndex, string $name): array {}

}
