<?php

namespace Bravo;

/**
 * Bravo\Di
 *
 * Bravo\Di is a component that implements Dependency Injection/Service Location
 * of services and it's itself a container for them.
 *
 * Since Bravo is highly decoupled, Bravo\Di is essential to integrate the different
 * components of the framework. The developer can also use this component to inject dependencies
 * and manage global instances of the different classes used in the application.
 *
 * Basically, this component implements the `Inversion of Control` pattern. Applying this,
 * the objects do not receive their dependencies using setters or constructors, but requesting
 * a service dependency injector. This reduces the overall complexity, since there is only one
 * way to get the required dependencies within a component.
 *
 * Additionally, this pattern increases testability in the code, thus making it less prone to errors.
 *
 * <code>
 * use Bravo\Di;
 * use Bravo\Http\Request;
 *
 * $di = new Di();
 *
 * // Using a string definition
 * $di->set("request", Request::class, true);
 *
 * // Using an anonymous function
 * $di->setShared(
 *     "request",
 *     function () {
 *         return new Request();
 *     }
 * );
 *
 * $request = $di->getRequest();
 * </code>
 */
class Di implements \Bravo\DiInterface
{
    /**
     * List of registered services
     */
    protected $_services;

    /**
     * List of shared instances
     */
    protected $_sharedInstances;

    /**
     * To know if the latest resolved instance was shared or not
     */
    protected $_freshInstance = false;

    /**
     * Events Manager
     *
     * @var \Bravo\Events\ManagerInterface
     */
    protected $_eventsManager;

    /**
     * Latest DI build
     */
    static protected $_default;


    /**
     * Bravo\Di constructor
     */
    public function __construct() {}

    /**
     * Sets the internal event manager
     *
     * @param \Bravo\Events\ManagerInterface $eventsManager
     */
    public function setInternalEventsManager(\Bravo\Events\ManagerInterface $eventsManager) {}

    /**
     * Returns the internal event manager
     *
     * @return \Bravo\Events\ManagerInterface
     */
    public function getInternalEventsManager(): ManagerInterface {}

    /**
     * Registers a service in the services container
     *
     * @param string $name
     * @param mixed $definition
     * @param bool $shared
     * @return \Bravo\Di\ServiceInterface
     */
    public function set(string $name, $definition, bool $shared = false): ServiceInterface {}

    /**
     * Registers an "always shared" service in the services container
     *
     * @param string $name
     * @param mixed $definition
     * @return \Bravo\Di\ServiceInterface
     */
    public function setShared(string $name, $definition): ServiceInterface {}

    /**
     * Removes a service in the services container
     * It also removes any shared instance created for the service
     *
     * @param string $name
     */
    public function remove(string $name) {}

    /**
     * Attempts to register a service in the services container
     * Only is successful if a service hasn't been registered previously
     * with the same name
     *
     * @param string $name
     * @param mixed $definition
     * @param bool $shared
     * @return bool|\Bravo\Di\ServiceInterface
     */
    public function attempt(string $name, $definition, bool $shared = false) {}

    /**
     * Sets a service using a raw Bravo\Di\Service definition
     *
     * @param string $name
     * @param \Bravo\Di\ServiceInterface $rawDefinition
     * @return \Bravo\Di\ServiceInterface
     */
    public function setRaw(string $name, \Bravo\Di\ServiceInterface $rawDefinition): ServiceInterface {}

    /**
     * Returns a service definition without resolving
     *
     * @param string $name
     * @return mixed
     */
    public function getRaw(string $name) {}

    /**
     * Returns a Bravo\Di\Service instance
     *
     * @param string $name
     * @return \Bravo\Di\ServiceInterface
     */
    public function getService(string $name): ServiceInterface {}

    /**
     * Resolves the service based on its configuration
     *
     * @param string $name
     * @param mixed $parameters
     * @return mixed
     */
    public function get(string $name, $parameters = null) {}

    /**
     * Resolves a service, the resolved service is stored in the DI, subsequent
     * requests for this service will return the same instance
     *
     * @param string $name
     * @param array $parameters
     * @return mixed
     */
    public function getShared(string $name, $parameters = null) {}

    /**
     * Check whether the DI contains a service by a name
     *
     * @param string $name
     * @return bool
     */
    public function has(string $name): bool {}

    /**
     * Check whether the last service obtained via getShared produced a fresh instance or an existing one
     *
     * @return bool
     */
    public function wasFreshInstance(): bool {}

    /**
     * Return the services registered in the DI
     *
     * @return array|\Bravo\Di\Service[]
     */
    public function getServices(): array {}

    /**
     * Check if a service is registered using the array syntax
     *
     * @param mixed $name
     * @return bool
     */
    public function offsetExists($name): bool {}

    /**
     * Allows to register a shared service using the array syntax
     *
     * <code>
     * $di["request"] = new \Bravo\Http\Request();
     * </code>
     *
     * @param mixed $name
     * @param mixed $definition
     * @return bool
     */
    public function offsetSet($name, $definition): bool {}

    /**
     * Allows to obtain a shared service using the array syntax
     *
     * <code>
     * var_dump($di["request"]);
     * </code>
     *
     * @param mixed $name
     * @return mixed
     */
    public function offsetGet($name) {}

    /**
     * Removes a service from the services container using the array syntax
     *
     * @param mixed $name
     * @return bool
     */
    public function offsetUnset($name): bool {}

    /**
     * Magic method to get or set services using setters/getters
     *
     * @param string $method
     * @param mixed $arguments
     * @return mixed|null
     */
    public function __call(string $method, $arguments = null): ? {}

    /**
     * Registers a service provider.
     *
     * <code>
     * use Bravo\DiInterface;
     * use Bravo\Di\ServiceProviderInterface;
     *
     * class SomeServiceProvider implements ServiceProviderInterface
     * {
     *     public function register(DiInterface $di)
     *     {
     *         $di->setShared('service', function () {
     *             // ...
     *         });
     *     }
     * }
     * </code>
     *
     * @param \Bravo\Di\ServiceProviderInterface $provider
     */
    public function register(\Bravo\Di\ServiceProviderInterface $provider): void {}

    /**
     * Set a default dependency injection container to be obtained into static methods
     *
     * @param \Bravo\DiInterface $dependencyInjector
     */
    public static function setDefault(\Bravo\DiInterface $dependencyInjector) {}

    /**
     * Return the latest DI created
     *
     * @return \Bravo\DiInterface
     */
    public static function getDefault(): DiInterface {}

    /**
     * Resets the internal default DI
     */
    public static function reset() {}

}
