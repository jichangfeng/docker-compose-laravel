<?php

namespace Bravo\Events;

/**
 * Bravo\Events\Exception
 *
 * Exceptions thrown in Bravo\Events will use this class
 */
class Exception extends \Bravo\Exception
{

}
