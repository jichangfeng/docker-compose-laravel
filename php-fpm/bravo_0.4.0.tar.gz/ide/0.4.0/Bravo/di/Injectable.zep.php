<?php

namespace Bravo\Di;

/**
 * Bravo\Di\Injectable
 *
 * This class allows to access services in the services container by just only accessing a public property
 * with the same name of a registered service
 *
 * @property \Bravo\Di|\Bravo\DiInterface $di
 */
abstract class Injectable implements \Bravo\Di\InjectionAwareInterface, \Bravo\Events\EventsAwareInterface
{
    /**
     * Dependency Injector
     *
     * @var \Bravo\DiInterface
     */
    protected $_dependencyInjector;

    /**
     * Events Manager
     *
     * @var \Bravo\Events\ManagerInterface
     */
    protected $_eventsManager;


    /**
     * Sets the dependency injector
     *
     * @param \Bravo\DiInterface $dependencyInjector
     */
    public function setDI(\Bravo\DiInterface $dependencyInjector) {}

    /**
     * Returns the internal dependency injector
     *
     * @return \Bravo\DiInterface
     */
    public function getDI(): DiInterface {}

    /**
     * Sets the event manager
     *
     * @param \Bravo\Events\ManagerInterface $eventsManager
     */
    public function setEventsManager(\Bravo\Events\ManagerInterface $eventsManager) {}

    /**
     * Returns the internal event manager
     *
     * @return \Bravo\Events\ManagerInterface
     */
    public function getEventsManager(): ManagerInterface {}

    /**
     * Magic method __get
     *
     * @param string $propertyName
     */
    public function __get(string $propertyName) {}

}
