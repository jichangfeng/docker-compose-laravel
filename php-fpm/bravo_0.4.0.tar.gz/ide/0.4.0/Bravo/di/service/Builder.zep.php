<?php

namespace Bravo\Di\Service;

/**
 * Bravo\Di\Service\Builder
 *
 * This class builds instances based on complex definitions
 */
class Builder
{

    /**
     * Resolves a constructor/call parameter
     *
     * @param \Bravo\DiInterface $dependencyInjector
     * @param int $position
     * @param array $argument
     * @return mixed
     */
    private function _buildParameter(\Bravo\DiInterface $dependencyInjector, int $position, array $argument) {}

    /**
     * Resolves an array of parameters
     *
     * @param \Bravo\DiInterface $dependencyInjector
     * @param array $arguments
     * @return array
     */
    private function _buildParameters(\Bravo\DiInterface $dependencyInjector, array $arguments): array {}

    /**
     * Builds a service using a complex service definition
     *
     * @param \Bravo\DiInterface $dependencyInjector
     * @param array $definition
     * @param array $parameters
     * @return mixed
     */
    public function build(\Bravo\DiInterface $dependencyInjector, array $definition, $parameters = null) {}

}
