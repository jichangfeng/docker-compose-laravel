<?php

namespace Bravo\Di;

/**
 * Bravo\Di\Exception
 *
 * Exceptions thrown in Bravo\Di will use this class
 */
class Exception extends \Bravo\Exception
{

}
