<?php

namespace Bravo\Di;

/**
 * Bravo\Di\InjectionAwareInterface
 *
 * This interface must be implemented in those classes that uses internally the Bravo\Di that creates them
 */
interface InjectionAwareInterface
{

    /**
     * Sets the dependency injector
     *
     * @param \Bravo\DiInterface $dependencyInjector
     */
    public function setDI(\Bravo\DiInterface $dependencyInjector);

    /**
     * Returns the internal dependency injector
     *
     * @return null|\Bravo\DiInterface
     */
    public function getDI(): ?DiInterface;

}
