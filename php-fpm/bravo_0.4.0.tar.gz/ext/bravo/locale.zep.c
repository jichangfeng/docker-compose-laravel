
#ifdef HAVE_CONFIG_H
#include "../ext_config.h"
#endif

#include <php.h>
#include "../php_ext.h"
#include "../ext.h"

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/main.h"
#include "kernel/fcall.h"
#include "kernel/memory.h"
#include "kernel/object.h"
#include "kernel/concat.h"
#include "kernel/operators.h"
#include "kernel/array.h"
#include "ext/spl/spl_exceptions.h"
#include "kernel/exception.h"
#include "kernel/iterator.h"
#include "ext/spl/spl_directory.h"
#include "kernel/string.h"
#include "kernel/file.h"


/**
 * Bravo\Locale
 *
 * Bravo\Locale is a component that implements Locale help utilities.
 *
 */
ZEPHIR_INIT_CLASS(Bravo_Locale) {

	ZEPHIR_REGISTER_CLASS(Bravo, Locale, bravo, locale, bravo_locale_method_entry, 0);

	return SUCCESS;

}

/**
 * Gets languages array and their quality accepted by the browser/client from _SERVER["HTTP_ACCEPT_LANGUAGE"]
 */
PHP_METHOD(Bravo_Locale, getLanguages) {

	zval _1, _2;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_0 = NULL;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2);

	ZEPHIR_MM_GROW();

	ZEPHIR_INIT_VAR(&_1);
	ZVAL_STRING(&_1, "HTTP_ACCEPT_LANGUAGE");
	ZEPHIR_INIT_VAR(&_2);
	ZVAL_STRING(&_2, "language");
	ZEPHIR_RETURN_CALL_SELF("_getqualityheader", &_0, 14, &_1, &_2);
	zephir_check_call_status();
	RETURN_MM();

}

/**
 * Gets best language accepted by the browser/client from _SERVER["HTTP_ACCEPT_LANGUAGE"]
 */
PHP_METHOD(Bravo_Locale, getBestLanguage) {

	zval _1, _2;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_0 = NULL;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2);

	ZEPHIR_MM_GROW();

	ZEPHIR_CALL_SELF(&_1, "getlanguages", NULL, 0);
	zephir_check_call_status();
	ZEPHIR_INIT_VAR(&_2);
	ZVAL_STRING(&_2, "language");
	ZEPHIR_RETURN_CALL_SELF("_getbestquality", &_0, 15, &_1, &_2);
	zephir_check_call_status();
	RETURN_MM();

}

/**
 * load json files language resources from language directory 
 * @param string  locale
 * @param array   appLangDir
 * @param string  optionalLangDir 
 * @return array      
 */
PHP_METHOD(Bravo_Locale, loadJsonResource) {

	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_2 = NULL;
	zval *locale_param = NULL, *appLangDir_param = NULL, *optionalLangDir_param = NULL, messages, fallbackLocale, localeDir, _1, _3, _4, _6$$4, _8$$4, _9$$4;
	zval locale, appLangDir, optionalLangDir, _0, _5$$4, _7$$5;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&locale);
	ZVAL_UNDEF(&appLangDir);
	ZVAL_UNDEF(&optionalLangDir);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_5$$4);
	ZVAL_UNDEF(&_7$$5);
	ZVAL_UNDEF(&messages);
	ZVAL_UNDEF(&fallbackLocale);
	ZVAL_UNDEF(&localeDir);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&_4);
	ZVAL_UNDEF(&_6$$4);
	ZVAL_UNDEF(&_8$$4);
	ZVAL_UNDEF(&_9$$4);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 2, 1, &locale_param, &appLangDir_param, &optionalLangDir_param);

	if (UNEXPECTED(Z_TYPE_P(locale_param) != IS_STRING && Z_TYPE_P(locale_param) != IS_NULL)) {
		zephir_throw_exception_string(spl_ce_InvalidArgumentException, SL("Parameter 'locale' must be of the type string") TSRMLS_CC);
		RETURN_MM_NULL();
	}
	if (EXPECTED(Z_TYPE_P(locale_param) == IS_STRING)) {
		zephir_get_strval(&locale, locale_param);
	} else {
		ZEPHIR_INIT_VAR(&locale);
		ZVAL_EMPTY_STRING(&locale);
	}
	if (UNEXPECTED(Z_TYPE_P(appLangDir_param) != IS_STRING && Z_TYPE_P(appLangDir_param) != IS_NULL)) {
		zephir_throw_exception_string(spl_ce_InvalidArgumentException, SL("Parameter 'appLangDir' must be of the type string") TSRMLS_CC);
		RETURN_MM_NULL();
	}
	if (EXPECTED(Z_TYPE_P(appLangDir_param) == IS_STRING)) {
		zephir_get_strval(&appLangDir, appLangDir_param);
	} else {
		ZEPHIR_INIT_VAR(&appLangDir);
		ZVAL_EMPTY_STRING(&appLangDir);
	}
	if (!optionalLangDir_param) {
		ZEPHIR_INIT_VAR(&optionalLangDir);
		ZVAL_STRING(&optionalLangDir, "");
	} else {
		zephir_get_strval(&optionalLangDir, optionalLangDir_param);
	}


	ZEPHIR_INIT_VAR(&messages);
	array_init(&messages);
	ZEPHIR_INIT_VAR(&fallbackLocale);
	ZVAL_STRING(&fallbackLocale, "en");
	ZEPHIR_INIT_VAR(&_0);
	ZEPHIR_CONCAT_VSV(&_0, &appLangDir, "/", &locale);
	ZEPHIR_CPY_WRT(&localeDir, &_0);
	ZEPHIR_CALL_FUNCTION(&_1, "is_dir", &_2, 16, &localeDir);
	zephir_check_call_status();
	if (!(zephir_is_true(&_1))) {
		ZEPHIR_INIT_NVAR(&localeDir);
		ZEPHIR_CONCAT_VSV(&localeDir, &appLangDir, "/", &fallbackLocale);
	}
	ZEPHIR_INIT_VAR(&_3);
	ZEPHIR_CALL_SELF(&_4, "_loadjsonfromlangdir", NULL, 0, &localeDir);
	zephir_check_call_status();
	zephir_fast_array_merge(&_3, &messages, &_4 TSRMLS_CC);
	ZEPHIR_CPY_WRT(&messages, &_3);
	if (!(ZEPHIR_IS_EMPTY(&optionalLangDir))) {
		ZEPHIR_INIT_VAR(&_5$$4);
		ZEPHIR_CONCAT_VSV(&_5$$4, &optionalLangDir, "/", &locale);
		ZEPHIR_CPY_WRT(&localeDir, &_5$$4);
		ZEPHIR_CALL_FUNCTION(&_6$$4, "is_dir", &_2, 16, &localeDir);
		zephir_check_call_status();
		if (!(zephir_is_true(&_6$$4))) {
			ZEPHIR_INIT_VAR(&_7$$5);
			ZEPHIR_CONCAT_VSV(&_7$$5, &optionalLangDir, "/", &locale);
			ZEPHIR_CPY_WRT(&localeDir, &_7$$5);
		}
		ZEPHIR_INIT_VAR(&_8$$4);
		ZEPHIR_CALL_SELF(&_9$$4, "_loadjsonfromlangdir", NULL, 0, &localeDir);
		zephir_check_call_status();
		zephir_fast_array_merge(&_8$$4, &messages, &_9$$4 TSRMLS_CC);
		ZEPHIR_CPY_WRT(&messages, &_8$$4);
	}
	RETURN_CCTOR(&messages);

}

/**
 * load json files language resources from language directory 
 * @param string  locale
 * @param array   appLangDir
 * @param string  optionalLangDir 
 * @return array      
 */
PHP_METHOD(Bravo_Locale, _loadJsonFromLangDir) {

	zend_object_iterator *_1$$3;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zval *localeDir_param = NULL, __$true, messages, item, jsonFile, curMessages, _0, _2$$3, _3$$4, _4$$5, _5$$5;
	zval localeDir;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&localeDir);
	ZVAL_BOOL(&__$true, 1);
	ZVAL_UNDEF(&messages);
	ZVAL_UNDEF(&item);
	ZVAL_UNDEF(&jsonFile);
	ZVAL_UNDEF(&curMessages);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_2$$3);
	ZVAL_UNDEF(&_3$$4);
	ZVAL_UNDEF(&_4$$5);
	ZVAL_UNDEF(&_5$$5);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &localeDir_param);

	if (UNEXPECTED(Z_TYPE_P(localeDir_param) != IS_STRING && Z_TYPE_P(localeDir_param) != IS_NULL)) {
		zephir_throw_exception_string(spl_ce_InvalidArgumentException, SL("Parameter 'localeDir' must be of the type string") TSRMLS_CC);
		RETURN_MM_NULL();
	}
	if (EXPECTED(Z_TYPE_P(localeDir_param) == IS_STRING)) {
		zephir_get_strval(&localeDir, localeDir_param);
	} else {
		ZEPHIR_INIT_VAR(&localeDir);
		ZVAL_EMPTY_STRING(&localeDir);
	}


	ZEPHIR_INIT_VAR(&messages);
	array_init(&messages);
	ZEPHIR_CALL_FUNCTION(&_0, "is_dir", NULL, 16, &localeDir);
	zephir_check_call_status();
	if (zephir_is_true(&_0)) {
		ZEPHIR_INIT_VAR(&_2$$3);
		object_init_ex(&_2$$3, spl_ce_DirectoryIterator);
		ZEPHIR_CALL_METHOD(NULL, &_2$$3, "__construct", NULL, 17, &localeDir);
		zephir_check_call_status();
		_1$$3 = zephir_get_iterator(&_2$$3 TSRMLS_CC);
		_1$$3->funcs->rewind(_1$$3 TSRMLS_CC);
		for (;_1$$3->funcs->valid(_1$$3 TSRMLS_CC) == SUCCESS && !EG(exception); _1$$3->funcs->move_forward(_1$$3 TSRMLS_CC)) {
			{
				ZEPHIR_ITERATOR_COPY(&item, _1$$3);
			}
			ZEPHIR_CALL_METHOD(&_3$$4, &item, "isfile", NULL, 0);
			zephir_check_call_status();
			if (EXPECTED(ZEPHIR_IS_TRUE(&_3$$4))) {
				ZEPHIR_CALL_METHOD(&jsonFile, &item, "getpathname", NULL, 0);
				zephir_check_call_status();
				ZEPHIR_INIT_NVAR(&_4$$5);
				zephir_file_get_contents(&_4$$5, &jsonFile TSRMLS_CC);
				ZEPHIR_INIT_NVAR(&curMessages);
				zephir_json_decode(&curMessages, &_4$$5, zephir_get_intval(&__$true) );
				ZEPHIR_INIT_NVAR(&_5$$5);
				zephir_fast_array_merge(&_5$$5, &messages, &curMessages TSRMLS_CC);
				ZEPHIR_CPY_WRT(&messages, &_5$$5);
			}
		}
		zend_iterator_dtor(_1$$3);
	}
	RETURN_CCTOR(&messages);

}

/**
 * Gets variable from $_SERVER superglobal
 */
PHP_METHOD(Bravo_Locale, _getServer) {

	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zval *name_param = NULL, _SERVER, serverValue;
	zval name;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&name);
	ZVAL_UNDEF(&_SERVER);
	ZVAL_UNDEF(&serverValue);

	ZEPHIR_MM_GROW();
	zephir_get_global(&_SERVER, SL("_SERVER"));
	zephir_fetch_params(1, 1, 0, &name_param);

	if (UNEXPECTED(Z_TYPE_P(name_param) != IS_STRING && Z_TYPE_P(name_param) != IS_NULL)) {
		zephir_throw_exception_string(spl_ce_InvalidArgumentException, SL("Parameter 'name' must be of the type string") TSRMLS_CC);
		RETURN_MM_NULL();
	}
	if (EXPECTED(Z_TYPE_P(name_param) == IS_STRING)) {
		zephir_get_strval(&name, name_param);
	} else {
		ZEPHIR_INIT_VAR(&name);
		ZVAL_EMPTY_STRING(&name);
	}


	if (zephir_array_isset_fetch(&serverValue, &_SERVER, &name, 1 TSRMLS_CC)) {
		RETURN_CTOR(&serverValue);
	}
	RETURN_MM_NULL();

}

/**
 * Process a request header and return the one with best quality
 */
PHP_METHOD(Bravo_Locale, _getBestQuality) {

	double quality = 0, acceptQuality = 0;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS, i = 0;
	zval name;
	zval *qualityParts_param = NULL, *name_param = NULL, selectedName, accept, *_0, _1, _2$$4, _3$$5, _4$$8, _5$$9;
	zval qualityParts;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&qualityParts);
	ZVAL_UNDEF(&selectedName);
	ZVAL_UNDEF(&accept);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2$$4);
	ZVAL_UNDEF(&_3$$5);
	ZVAL_UNDEF(&_4$$8);
	ZVAL_UNDEF(&_5$$9);
	ZVAL_UNDEF(&name);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 2, 0, &qualityParts_param, &name_param);

	zephir_get_arrval(&qualityParts, qualityParts_param);
	if (UNEXPECTED(Z_TYPE_P(name_param) != IS_STRING && Z_TYPE_P(name_param) != IS_NULL)) {
		zephir_throw_exception_string(spl_ce_InvalidArgumentException, SL("Parameter 'name' must be of the type string") TSRMLS_CC);
		RETURN_MM_NULL();
	}
	if (EXPECTED(Z_TYPE_P(name_param) == IS_STRING)) {
		zephir_get_strval(&name, name_param);
	} else {
		ZEPHIR_INIT_VAR(&name);
		ZVAL_EMPTY_STRING(&name);
	}


	i = 0;
	quality = 0.0;
	ZEPHIR_INIT_VAR(&selectedName);
	ZVAL_STRING(&selectedName, "");
	zephir_is_iterable(&qualityParts, 0, "bravo/locale.zep", 142);
	if (Z_TYPE_P(&qualityParts) == IS_ARRAY) {
		ZEND_HASH_FOREACH_VAL(Z_ARRVAL_P(&qualityParts), _0)
		{
			ZEPHIR_INIT_NVAR(&accept);
			ZVAL_COPY(&accept, _0);
			if (i == 0) {
				ZEPHIR_OBS_NVAR(&_2$$4);
				zephir_array_fetch_string(&_2$$4, &accept, SL("quality"), PH_NOISY, "bravo/locale.zep", 131 TSRMLS_CC);
				quality = zephir_get_doubleval(&_2$$4);
				ZEPHIR_OBS_NVAR(&selectedName);
				zephir_array_fetch(&selectedName, &accept, &name, PH_NOISY, "bravo/locale.zep", 132 TSRMLS_CC);
			} else {
				ZEPHIR_OBS_NVAR(&_3$$5);
				zephir_array_fetch_string(&_3$$5, &accept, SL("quality"), PH_NOISY, "bravo/locale.zep", 134 TSRMLS_CC);
				acceptQuality = zephir_get_doubleval(&_3$$5);
				if (acceptQuality > quality) {
					quality = acceptQuality;
					ZEPHIR_OBS_NVAR(&selectedName);
					zephir_array_fetch(&selectedName, &accept, &name, PH_NOISY, "bravo/locale.zep", 137 TSRMLS_CC);
				}
			}
			i++;
		} ZEND_HASH_FOREACH_END();
	} else {
		ZEPHIR_CALL_METHOD(NULL, &qualityParts, "rewind", NULL, 0);
		zephir_check_call_status();
		while (1) {
			ZEPHIR_CALL_METHOD(&_1, &qualityParts, "valid", NULL, 0);
			zephir_check_call_status();
			if (!zend_is_true(&_1)) {
				break;
			}
			ZEPHIR_CALL_METHOD(&accept, &qualityParts, "current", NULL, 0);
			zephir_check_call_status();
				if (i == 0) {
					ZEPHIR_OBS_NVAR(&_4$$8);
					zephir_array_fetch_string(&_4$$8, &accept, SL("quality"), PH_NOISY, "bravo/locale.zep", 131 TSRMLS_CC);
					quality = zephir_get_doubleval(&_4$$8);
					ZEPHIR_OBS_NVAR(&selectedName);
					zephir_array_fetch(&selectedName, &accept, &name, PH_NOISY, "bravo/locale.zep", 132 TSRMLS_CC);
				} else {
					ZEPHIR_OBS_NVAR(&_5$$9);
					zephir_array_fetch_string(&_5$$9, &accept, SL("quality"), PH_NOISY, "bravo/locale.zep", 134 TSRMLS_CC);
					acceptQuality = zephir_get_doubleval(&_5$$9);
					if (acceptQuality > quality) {
						quality = acceptQuality;
						ZEPHIR_OBS_NVAR(&selectedName);
						zephir_array_fetch(&selectedName, &accept, &name, PH_NOISY, "bravo/locale.zep", 137 TSRMLS_CC);
					}
				}
				i++;
			ZEPHIR_CALL_METHOD(NULL, &qualityParts, "next", NULL, 0);
			zephir_check_call_status();
		}
	}
	ZEPHIR_INIT_NVAR(&accept);
	RETURN_CCTOR(&selectedName);

}

/**
 * Process a request header and return an array of values with their qualities
 */
PHP_METHOD(Bravo_Locale, _getQualityHeader) {

	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_1 = NULL, *_6 = NULL;
	zval *serverIndex_param = NULL, *name_param = NULL, returnedParts, part, headerParts, headerPart, split, _0, _2, _3, _4, _5, *_7, _8, _9$$3, _10$$3, _11$$3, _12$$3, _13$$3, *_14$$3, _15$$3, _16$$4, _17$$4, _18$$5, _19$$6, _20$$6, _21$$7, _22$$7, _23$$8, _24$$9, _25$$9, _26$$10, _27$$11, _28$$11, _29$$12, _30$$12, _31$$13, _32$$14, _33$$14, _34$$14, _35$$14, _36$$14, *_37$$14, _38$$14, _39$$15, _40$$15, _41$$16, _42$$17, _43$$17, _44$$18, _45$$18, _46$$19, _47$$20, _48$$20, _49$$21, _50$$22, _51$$22, _52$$23, _53$$23, _54$$24;
	zval serverIndex, name;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&serverIndex);
	ZVAL_UNDEF(&name);
	ZVAL_UNDEF(&returnedParts);
	ZVAL_UNDEF(&part);
	ZVAL_UNDEF(&headerParts);
	ZVAL_UNDEF(&headerPart);
	ZVAL_UNDEF(&split);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&_4);
	ZVAL_UNDEF(&_5);
	ZVAL_UNDEF(&_8);
	ZVAL_UNDEF(&_9$$3);
	ZVAL_UNDEF(&_10$$3);
	ZVAL_UNDEF(&_11$$3);
	ZVAL_UNDEF(&_12$$3);
	ZVAL_UNDEF(&_13$$3);
	ZVAL_UNDEF(&_15$$3);
	ZVAL_UNDEF(&_16$$4);
	ZVAL_UNDEF(&_17$$4);
	ZVAL_UNDEF(&_18$$5);
	ZVAL_UNDEF(&_19$$6);
	ZVAL_UNDEF(&_20$$6);
	ZVAL_UNDEF(&_21$$7);
	ZVAL_UNDEF(&_22$$7);
	ZVAL_UNDEF(&_23$$8);
	ZVAL_UNDEF(&_24$$9);
	ZVAL_UNDEF(&_25$$9);
	ZVAL_UNDEF(&_26$$10);
	ZVAL_UNDEF(&_27$$11);
	ZVAL_UNDEF(&_28$$11);
	ZVAL_UNDEF(&_29$$12);
	ZVAL_UNDEF(&_30$$12);
	ZVAL_UNDEF(&_31$$13);
	ZVAL_UNDEF(&_32$$14);
	ZVAL_UNDEF(&_33$$14);
	ZVAL_UNDEF(&_34$$14);
	ZVAL_UNDEF(&_35$$14);
	ZVAL_UNDEF(&_36$$14);
	ZVAL_UNDEF(&_38$$14);
	ZVAL_UNDEF(&_39$$15);
	ZVAL_UNDEF(&_40$$15);
	ZVAL_UNDEF(&_41$$16);
	ZVAL_UNDEF(&_42$$17);
	ZVAL_UNDEF(&_43$$17);
	ZVAL_UNDEF(&_44$$18);
	ZVAL_UNDEF(&_45$$18);
	ZVAL_UNDEF(&_46$$19);
	ZVAL_UNDEF(&_47$$20);
	ZVAL_UNDEF(&_48$$20);
	ZVAL_UNDEF(&_49$$21);
	ZVAL_UNDEF(&_50$$22);
	ZVAL_UNDEF(&_51$$22);
	ZVAL_UNDEF(&_52$$23);
	ZVAL_UNDEF(&_53$$23);
	ZVAL_UNDEF(&_54$$24);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 2, 0, &serverIndex_param, &name_param);

	if (UNEXPECTED(Z_TYPE_P(serverIndex_param) != IS_STRING && Z_TYPE_P(serverIndex_param) != IS_NULL)) {
		zephir_throw_exception_string(spl_ce_InvalidArgumentException, SL("Parameter 'serverIndex' must be of the type string") TSRMLS_CC);
		RETURN_MM_NULL();
	}
	if (EXPECTED(Z_TYPE_P(serverIndex_param) == IS_STRING)) {
		zephir_get_strval(&serverIndex, serverIndex_param);
	} else {
		ZEPHIR_INIT_VAR(&serverIndex);
		ZVAL_EMPTY_STRING(&serverIndex);
	}
	if (UNEXPECTED(Z_TYPE_P(name_param) != IS_STRING && Z_TYPE_P(name_param) != IS_NULL)) {
		zephir_throw_exception_string(spl_ce_InvalidArgumentException, SL("Parameter 'name' must be of the type string") TSRMLS_CC);
		RETURN_MM_NULL();
	}
	if (EXPECTED(Z_TYPE_P(name_param) == IS_STRING)) {
		zephir_get_strval(&name, name_param);
	} else {
		ZEPHIR_INIT_VAR(&name);
		ZVAL_EMPTY_STRING(&name);
	}


	ZEPHIR_INIT_VAR(&returnedParts);
	array_init(&returnedParts);
	ZEPHIR_CALL_SELF(&_0, "_getserver", &_1, 18, &serverIndex);
	zephir_check_call_status();
	ZEPHIR_INIT_VAR(&_2);
	ZVAL_STRING(&_2, "/,\\s*/");
	ZVAL_LONG(&_3, -1);
	ZVAL_LONG(&_4, 1);
	ZEPHIR_CALL_FUNCTION(&_5, "preg_split", &_6, 19, &_2, &_0, &_3, &_4);
	zephir_check_call_status();
	zephir_is_iterable(&_5, 0, "bravo/locale.zep", 173);
	if (Z_TYPE_P(&_5) == IS_ARRAY) {
		ZEND_HASH_FOREACH_VAL(Z_ARRVAL_P(&_5), _7)
		{
			ZEPHIR_INIT_NVAR(&part);
			ZVAL_COPY(&part, _7);
			ZEPHIR_INIT_NVAR(&headerParts);
			array_init(&headerParts);
			ZEPHIR_INIT_NVAR(&_9$$3);
			zephir_fast_trim(&_9$$3, &part, NULL , ZEPHIR_TRIM_BOTH TSRMLS_CC);
			ZEPHIR_INIT_NVAR(&_10$$3);
			ZVAL_STRING(&_10$$3, "/\\s*;\\s*/");
			ZVAL_LONG(&_11$$3, -1);
			ZVAL_LONG(&_12$$3, 1);
			ZEPHIR_CALL_FUNCTION(&_13$$3, "preg_split", &_6, 19, &_10$$3, &_9$$3, &_11$$3, &_12$$3);
			zephir_check_call_status();
			zephir_is_iterable(&_13$$3, 0, "bravo/locale.zep", 170);
			if (Z_TYPE_P(&_13$$3) == IS_ARRAY) {
				ZEND_HASH_FOREACH_VAL(Z_ARRVAL_P(&_13$$3), _14$$3)
				{
					ZEPHIR_INIT_NVAR(&headerPart);
					ZVAL_COPY(&headerPart, _14$$3);
					ZEPHIR_INIT_NVAR(&_16$$4);
					ZVAL_STRING(&_16$$4, "=");
					ZEPHIR_INIT_NVAR(&_17$$4);
					zephir_fast_strpos(&_17$$4, &headerPart, &_16$$4, 0 );
					if (!ZEPHIR_IS_FALSE_IDENTICAL(&_17$$4)) {
						ZEPHIR_INIT_NVAR(&split);
						zephir_fast_explode_str(&split, SL("="), &headerPart, 2  TSRMLS_CC);
						zephir_array_fetch_long(&_18$$5, &split, 0, PH_NOISY | PH_READONLY, "bravo/locale.zep", 159 TSRMLS_CC);
						if (ZEPHIR_IS_STRING_IDENTICAL(&_18$$5, "q")) {
							ZEPHIR_OBS_NVAR(&_19$$6);
							zephir_array_fetch_long(&_19$$6, &split, 1, PH_NOISY, "bravo/locale.zep", 160 TSRMLS_CC);
							ZEPHIR_INIT_NVAR(&_20$$6);
							ZVAL_DOUBLE(&_20$$6, zephir_get_doubleval(&_19$$6));
							zephir_array_update_string(&headerParts, SL("quality"), &_20$$6, PH_COPY | PH_SEPARATE);
						} else {
							zephir_array_fetch_long(&_21$$7, &split, 1, PH_NOISY | PH_READONLY, "bravo/locale.zep", 162 TSRMLS_CC);
							ZEPHIR_OBS_NVAR(&_22$$7);
							zephir_array_fetch_long(&_22$$7, &split, 0, PH_NOISY, "bravo/locale.zep", 162 TSRMLS_CC);
							zephir_array_update_zval(&headerParts, &_22$$7, &_21$$7, PH_COPY | PH_SEPARATE);
						}
					} else {
						zephir_array_update_zval(&headerParts, &name, &headerPart, PH_COPY | PH_SEPARATE);
						ZEPHIR_INIT_NVAR(&_23$$8);
						ZVAL_DOUBLE(&_23$$8, 1.0);
						zephir_array_update_string(&headerParts, SL("quality"), &_23$$8, PH_COPY | PH_SEPARATE);
					}
				} ZEND_HASH_FOREACH_END();
			} else {
				ZEPHIR_CALL_METHOD(NULL, &_13$$3, "rewind", NULL, 0);
				zephir_check_call_status();
				while (1) {
					ZEPHIR_CALL_METHOD(&_15$$3, &_13$$3, "valid", NULL, 0);
					zephir_check_call_status();
					if (!zend_is_true(&_15$$3)) {
						break;
					}
					ZEPHIR_CALL_METHOD(&headerPart, &_13$$3, "current", NULL, 0);
					zephir_check_call_status();
						ZEPHIR_INIT_NVAR(&_24$$9);
						ZVAL_STRING(&_24$$9, "=");
						ZEPHIR_INIT_NVAR(&_25$$9);
						zephir_fast_strpos(&_25$$9, &headerPart, &_24$$9, 0 );
						if (!ZEPHIR_IS_FALSE_IDENTICAL(&_25$$9)) {
							ZEPHIR_INIT_NVAR(&split);
							zephir_fast_explode_str(&split, SL("="), &headerPart, 2  TSRMLS_CC);
							zephir_array_fetch_long(&_26$$10, &split, 0, PH_NOISY | PH_READONLY, "bravo/locale.zep", 159 TSRMLS_CC);
							if (ZEPHIR_IS_STRING_IDENTICAL(&_26$$10, "q")) {
								ZEPHIR_OBS_NVAR(&_27$$11);
								zephir_array_fetch_long(&_27$$11, &split, 1, PH_NOISY, "bravo/locale.zep", 160 TSRMLS_CC);
								ZEPHIR_INIT_NVAR(&_28$$11);
								ZVAL_DOUBLE(&_28$$11, zephir_get_doubleval(&_27$$11));
								zephir_array_update_string(&headerParts, SL("quality"), &_28$$11, PH_COPY | PH_SEPARATE);
							} else {
								zephir_array_fetch_long(&_29$$12, &split, 1, PH_NOISY | PH_READONLY, "bravo/locale.zep", 162 TSRMLS_CC);
								ZEPHIR_OBS_NVAR(&_30$$12);
								zephir_array_fetch_long(&_30$$12, &split, 0, PH_NOISY, "bravo/locale.zep", 162 TSRMLS_CC);
								zephir_array_update_zval(&headerParts, &_30$$12, &_29$$12, PH_COPY | PH_SEPARATE);
							}
						} else {
							zephir_array_update_zval(&headerParts, &name, &headerPart, PH_COPY | PH_SEPARATE);
							ZEPHIR_INIT_NVAR(&_31$$13);
							ZVAL_DOUBLE(&_31$$13, 1.0);
							zephir_array_update_string(&headerParts, SL("quality"), &_31$$13, PH_COPY | PH_SEPARATE);
						}
					ZEPHIR_CALL_METHOD(NULL, &_13$$3, "next", NULL, 0);
					zephir_check_call_status();
				}
			}
			ZEPHIR_INIT_NVAR(&headerPart);
			zephir_array_append(&returnedParts, &headerParts, PH_SEPARATE, "bravo/locale.zep", 170);
		} ZEND_HASH_FOREACH_END();
	} else {
		ZEPHIR_CALL_METHOD(NULL, &_5, "rewind", NULL, 0);
		zephir_check_call_status();
		while (1) {
			ZEPHIR_CALL_METHOD(&_8, &_5, "valid", NULL, 0);
			zephir_check_call_status();
			if (!zend_is_true(&_8)) {
				break;
			}
			ZEPHIR_CALL_METHOD(&part, &_5, "current", NULL, 0);
			zephir_check_call_status();
				ZEPHIR_INIT_NVAR(&headerParts);
				array_init(&headerParts);
				ZEPHIR_INIT_NVAR(&_32$$14);
				zephir_fast_trim(&_32$$14, &part, NULL , ZEPHIR_TRIM_BOTH TSRMLS_CC);
				ZEPHIR_INIT_NVAR(&_33$$14);
				ZVAL_STRING(&_33$$14, "/\\s*;\\s*/");
				ZVAL_LONG(&_34$$14, -1);
				ZVAL_LONG(&_35$$14, 1);
				ZEPHIR_CALL_FUNCTION(&_36$$14, "preg_split", &_6, 19, &_33$$14, &_32$$14, &_34$$14, &_35$$14);
				zephir_check_call_status();
				zephir_is_iterable(&_36$$14, 0, "bravo/locale.zep", 170);
				if (Z_TYPE_P(&_36$$14) == IS_ARRAY) {
					ZEND_HASH_FOREACH_VAL(Z_ARRVAL_P(&_36$$14), _37$$14)
					{
						ZEPHIR_INIT_NVAR(&headerPart);
						ZVAL_COPY(&headerPart, _37$$14);
						ZEPHIR_INIT_NVAR(&_39$$15);
						ZVAL_STRING(&_39$$15, "=");
						ZEPHIR_INIT_NVAR(&_40$$15);
						zephir_fast_strpos(&_40$$15, &headerPart, &_39$$15, 0 );
						if (!ZEPHIR_IS_FALSE_IDENTICAL(&_40$$15)) {
							ZEPHIR_INIT_NVAR(&split);
							zephir_fast_explode_str(&split, SL("="), &headerPart, 2  TSRMLS_CC);
							zephir_array_fetch_long(&_41$$16, &split, 0, PH_NOISY | PH_READONLY, "bravo/locale.zep", 159 TSRMLS_CC);
							if (ZEPHIR_IS_STRING_IDENTICAL(&_41$$16, "q")) {
								ZEPHIR_OBS_NVAR(&_42$$17);
								zephir_array_fetch_long(&_42$$17, &split, 1, PH_NOISY, "bravo/locale.zep", 160 TSRMLS_CC);
								ZEPHIR_INIT_NVAR(&_43$$17);
								ZVAL_DOUBLE(&_43$$17, zephir_get_doubleval(&_42$$17));
								zephir_array_update_string(&headerParts, SL("quality"), &_43$$17, PH_COPY | PH_SEPARATE);
							} else {
								zephir_array_fetch_long(&_44$$18, &split, 1, PH_NOISY | PH_READONLY, "bravo/locale.zep", 162 TSRMLS_CC);
								ZEPHIR_OBS_NVAR(&_45$$18);
								zephir_array_fetch_long(&_45$$18, &split, 0, PH_NOISY, "bravo/locale.zep", 162 TSRMLS_CC);
								zephir_array_update_zval(&headerParts, &_45$$18, &_44$$18, PH_COPY | PH_SEPARATE);
							}
						} else {
							zephir_array_update_zval(&headerParts, &name, &headerPart, PH_COPY | PH_SEPARATE);
							ZEPHIR_INIT_NVAR(&_46$$19);
							ZVAL_DOUBLE(&_46$$19, 1.0);
							zephir_array_update_string(&headerParts, SL("quality"), &_46$$19, PH_COPY | PH_SEPARATE);
						}
					} ZEND_HASH_FOREACH_END();
				} else {
					ZEPHIR_CALL_METHOD(NULL, &_36$$14, "rewind", NULL, 0);
					zephir_check_call_status();
					while (1) {
						ZEPHIR_CALL_METHOD(&_38$$14, &_36$$14, "valid", NULL, 0);
						zephir_check_call_status();
						if (!zend_is_true(&_38$$14)) {
							break;
						}
						ZEPHIR_CALL_METHOD(&headerPart, &_36$$14, "current", NULL, 0);
						zephir_check_call_status();
							ZEPHIR_INIT_NVAR(&_47$$20);
							ZVAL_STRING(&_47$$20, "=");
							ZEPHIR_INIT_NVAR(&_48$$20);
							zephir_fast_strpos(&_48$$20, &headerPart, &_47$$20, 0 );
							if (!ZEPHIR_IS_FALSE_IDENTICAL(&_48$$20)) {
								ZEPHIR_INIT_NVAR(&split);
								zephir_fast_explode_str(&split, SL("="), &headerPart, 2  TSRMLS_CC);
								zephir_array_fetch_long(&_49$$21, &split, 0, PH_NOISY | PH_READONLY, "bravo/locale.zep", 159 TSRMLS_CC);
								if (ZEPHIR_IS_STRING_IDENTICAL(&_49$$21, "q")) {
									ZEPHIR_OBS_NVAR(&_50$$22);
									zephir_array_fetch_long(&_50$$22, &split, 1, PH_NOISY, "bravo/locale.zep", 160 TSRMLS_CC);
									ZEPHIR_INIT_NVAR(&_51$$22);
									ZVAL_DOUBLE(&_51$$22, zephir_get_doubleval(&_50$$22));
									zephir_array_update_string(&headerParts, SL("quality"), &_51$$22, PH_COPY | PH_SEPARATE);
								} else {
									zephir_array_fetch_long(&_52$$23, &split, 1, PH_NOISY | PH_READONLY, "bravo/locale.zep", 162 TSRMLS_CC);
									ZEPHIR_OBS_NVAR(&_53$$23);
									zephir_array_fetch_long(&_53$$23, &split, 0, PH_NOISY, "bravo/locale.zep", 162 TSRMLS_CC);
									zephir_array_update_zval(&headerParts, &_53$$23, &_52$$23, PH_COPY | PH_SEPARATE);
								}
							} else {
								zephir_array_update_zval(&headerParts, &name, &headerPart, PH_COPY | PH_SEPARATE);
								ZEPHIR_INIT_NVAR(&_54$$24);
								ZVAL_DOUBLE(&_54$$24, 1.0);
								zephir_array_update_string(&headerParts, SL("quality"), &_54$$24, PH_COPY | PH_SEPARATE);
							}
						ZEPHIR_CALL_METHOD(NULL, &_36$$14, "next", NULL, 0);
						zephir_check_call_status();
					}
				}
				ZEPHIR_INIT_NVAR(&headerPart);
				zephir_array_append(&returnedParts, &headerParts, PH_SEPARATE, "bravo/locale.zep", 170);
			ZEPHIR_CALL_METHOD(NULL, &_5, "next", NULL, 0);
			zephir_check_call_status();
		}
	}
	ZEPHIR_INIT_NVAR(&part);
	RETURN_CCTOR(&returnedParts);

}

