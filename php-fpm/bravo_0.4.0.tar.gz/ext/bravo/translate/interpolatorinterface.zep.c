
#ifdef HAVE_CONFIG_H
#include "../../ext_config.h"
#endif

#include <php.h>
#include "../../php_ext.h"
#include "../../ext.h"

#include <Zend/zend_exceptions.h>

#include "kernel/main.h"


/**
 * Bravo\Translate\AdapterInterface
 *
 * Interface for Bravo\Translate adapters
 */
ZEPHIR_INIT_CLASS(Bravo_Translate_InterpolatorInterface) {

	ZEPHIR_REGISTER_INTERFACE(Bravo\\Translate, InterpolatorInterface, bravo, translate_interpolatorinterface, bravo_translate_interpolatorinterface_method_entry);

	return SUCCESS;

}

/**
 * Replaces placeholders by the values passed
 */
ZEPHIR_DOC_METHOD(Bravo_Translate_InterpolatorInterface, replacePlaceholders);

