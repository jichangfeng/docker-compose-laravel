
extern zend_class_entry *bravo_translate_adapter_nativearray_ce;

ZEPHIR_INIT_CLASS(Bravo_Translate_Adapter_NativeArray);

PHP_METHOD(Bravo_Translate_Adapter_NativeArray, __construct);
PHP_METHOD(Bravo_Translate_Adapter_NativeArray, query);
PHP_METHOD(Bravo_Translate_Adapter_NativeArray, exists);

ZEND_BEGIN_ARG_INFO_EX(arginfo_bravo_translate_adapter_nativearray___construct, 0, 0, 1)
	ZEND_ARG_ARRAY_INFO(0, options, 0)
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_translate_adapter_nativearray_query, 0, 1, IS_STRING, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_translate_adapter_nativearray_query, 0, 1, IS_STRING, NULL, 0)
#endif
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, index, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, index)
#endif
	ZEND_ARG_INFO(0, placeholders)
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_translate_adapter_nativearray_exists, 0, 1, _IS_BOOL, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_translate_adapter_nativearray_exists, 0, 1, _IS_BOOL, NULL, 0)
#endif
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, index, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, index)
#endif
ZEND_END_ARG_INFO()

ZEPHIR_INIT_FUNCS(bravo_translate_adapter_nativearray_method_entry) {
	PHP_ME(Bravo_Translate_Adapter_NativeArray, __construct, arginfo_bravo_translate_adapter_nativearray___construct, ZEND_ACC_PUBLIC|ZEND_ACC_CTOR)
	PHP_ME(Bravo_Translate_Adapter_NativeArray, query, arginfo_bravo_translate_adapter_nativearray_query, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Translate_Adapter_NativeArray, exists, arginfo_bravo_translate_adapter_nativearray_exists, ZEND_ACC_PUBLIC)
	PHP_FE_END
};
