
extern zend_class_entry *bravo_di_ce;

ZEPHIR_INIT_CLASS(Bravo_Di);

PHP_METHOD(Bravo_Di, __construct);
PHP_METHOD(Bravo_Di, setInternalEventsManager);
PHP_METHOD(Bravo_Di, getInternalEventsManager);
PHP_METHOD(Bravo_Di, set);
PHP_METHOD(Bravo_Di, setShared);
PHP_METHOD(Bravo_Di, remove);
PHP_METHOD(Bravo_Di, attempt);
PHP_METHOD(Bravo_Di, setRaw);
PHP_METHOD(Bravo_Di, getRaw);
PHP_METHOD(Bravo_Di, getService);
PHP_METHOD(Bravo_Di, get);
PHP_METHOD(Bravo_Di, getShared);
PHP_METHOD(Bravo_Di, has);
PHP_METHOD(Bravo_Di, wasFreshInstance);
PHP_METHOD(Bravo_Di, getServices);
PHP_METHOD(Bravo_Di, offsetExists);
PHP_METHOD(Bravo_Di, offsetSet);
PHP_METHOD(Bravo_Di, offsetGet);
PHP_METHOD(Bravo_Di, offsetUnset);
PHP_METHOD(Bravo_Di, __call);
PHP_METHOD(Bravo_Di, register);
PHP_METHOD(Bravo_Di, setDefault);
PHP_METHOD(Bravo_Di, getDefault);
PHP_METHOD(Bravo_Di, reset);

ZEND_BEGIN_ARG_INFO_EX(arginfo_bravo_di_setinternaleventsmanager, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, eventsManager, Bravo\\Events\\ManagerInterface, 0)
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(arginfo_bravo_di_getinternaleventsmanager, 0, 0, Bravo\\Events\\ManagerInterface, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_getinternaleventsmanager, 0, 0, IS_OBJECT, "Bravo\\Events\\ManagerInterface", 0)
#endif
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(arginfo_bravo_di_set, 0, 2, Bravo\\Di\\ServiceInterface, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_set, 0, 2, IS_OBJECT, "Bravo\\Di\\ServiceInterface", 0)
#endif
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, name)
#endif
	ZEND_ARG_INFO(0, definition)
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, shared, _IS_BOOL, 0)
#else
	ZEND_ARG_INFO(0, shared)
#endif
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(arginfo_bravo_di_setshared, 0, 2, Bravo\\Di\\ServiceInterface, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_setshared, 0, 2, IS_OBJECT, "Bravo\\Di\\ServiceInterface", 0)
#endif
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, name)
#endif
	ZEND_ARG_INFO(0, definition)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_bravo_di_remove, 0, 0, 1)
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, name)
#endif
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_bravo_di_attempt, 0, 0, 2)
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, name)
#endif
	ZEND_ARG_INFO(0, definition)
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, shared, _IS_BOOL, 0)
#else
	ZEND_ARG_INFO(0, shared)
#endif
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(arginfo_bravo_di_setraw, 0, 2, Bravo\\Di\\ServiceInterface, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_setraw, 0, 2, IS_OBJECT, "Bravo\\Di\\ServiceInterface", 0)
#endif
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, name)
#endif
	ZEND_ARG_OBJ_INFO(0, rawDefinition, Bravo\\Di\\ServiceInterface, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_bravo_di_getraw, 0, 0, 1)
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, name)
#endif
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(arginfo_bravo_di_getservice, 0, 1, Bravo\\Di\\ServiceInterface, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_getservice, 0, 1, IS_OBJECT, "Bravo\\Di\\ServiceInterface", 0)
#endif
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, name)
#endif
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_bravo_di_get, 0, 0, 1)
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, name)
#endif
	ZEND_ARG_INFO(0, parameters)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_bravo_di_getshared, 0, 0, 1)
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, name)
#endif
	ZEND_ARG_INFO(0, parameters)
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_has, 0, 1, _IS_BOOL, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_has, 0, 1, _IS_BOOL, NULL, 0)
#endif
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, name)
#endif
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_wasfreshinstance, 0, 0, _IS_BOOL, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_wasfreshinstance, 0, 0, _IS_BOOL, NULL, 0)
#endif
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_getservices, 0, 0, IS_ARRAY, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_getservices, 0, 0, IS_ARRAY, NULL, 0)
#endif
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_offsetexists, 0, 1, _IS_BOOL, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_offsetexists, 0, 1, _IS_BOOL, NULL, 0)
#endif
	ZEND_ARG_INFO(0, name)
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_offsetset, 0, 2, _IS_BOOL, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_offsetset, 0, 2, _IS_BOOL, NULL, 0)
#endif
	ZEND_ARG_INFO(0, name)
	ZEND_ARG_INFO(0, definition)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_bravo_di_offsetget, 0, 0, 1)
	ZEND_ARG_INFO(0, name)
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_offsetunset, 0, 1, _IS_BOOL, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_offsetunset, 0, 1, _IS_BOOL, NULL, 0)
#endif
	ZEND_ARG_INFO(0, name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_bravo_di___call, 0, 0, 1)
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, method, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, method)
#endif
	ZEND_ARG_INFO(0, arguments)
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70100
#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_register, 0, 1, IS_VOID, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_register, 0, 1, IS_VOID, NULL, 0)
#endif
#else
ZEND_BEGIN_ARG_INFO_EX(arginfo_bravo_di_register, 0, 0, 1)
#define arginfo_bravo_di_register NULL
#endif

	ZEND_ARG_OBJ_INFO(0, provider, Bravo\\Di\\ServiceProviderInterface, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_bravo_di_setdefault, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, dependencyInjector, Bravo\\DiInterface, 0)
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(arginfo_bravo_di_getdefault, 0, 0, Bravo\\DiInterface, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_getdefault, 0, 0, IS_OBJECT, "Bravo\\DiInterface", 0)
#endif
ZEND_END_ARG_INFO()

ZEPHIR_INIT_FUNCS(bravo_di_method_entry) {
	PHP_ME(Bravo_Di, __construct, NULL, ZEND_ACC_PUBLIC|ZEND_ACC_CTOR)
	PHP_ME(Bravo_Di, setInternalEventsManager, arginfo_bravo_di_setinternaleventsmanager, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, getInternalEventsManager, arginfo_bravo_di_getinternaleventsmanager, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, set, arginfo_bravo_di_set, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, setShared, arginfo_bravo_di_setshared, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, remove, arginfo_bravo_di_remove, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, attempt, arginfo_bravo_di_attempt, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, setRaw, arginfo_bravo_di_setraw, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, getRaw, arginfo_bravo_di_getraw, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, getService, arginfo_bravo_di_getservice, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, get, arginfo_bravo_di_get, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, getShared, arginfo_bravo_di_getshared, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, has, arginfo_bravo_di_has, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, wasFreshInstance, arginfo_bravo_di_wasfreshinstance, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, getServices, arginfo_bravo_di_getservices, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, offsetExists, arginfo_bravo_di_offsetexists, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, offsetSet, arginfo_bravo_di_offsetset, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, offsetGet, arginfo_bravo_di_offsetget, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, offsetUnset, arginfo_bravo_di_offsetunset, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, __call, arginfo_bravo_di___call, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, register, arginfo_bravo_di_register, ZEND_ACC_PUBLIC)
	PHP_ME(Bravo_Di, setDefault, arginfo_bravo_di_setdefault, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(Bravo_Di, getDefault, arginfo_bravo_di_getdefault, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(Bravo_Di, reset, NULL, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_FE_END
};
