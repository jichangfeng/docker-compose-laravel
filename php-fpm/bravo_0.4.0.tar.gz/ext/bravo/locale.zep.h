
extern zend_class_entry *bravo_locale_ce;

ZEPHIR_INIT_CLASS(Bravo_Locale);

PHP_METHOD(Bravo_Locale, getLanguages);
PHP_METHOD(Bravo_Locale, getBestLanguage);
PHP_METHOD(Bravo_Locale, loadJsonResource);
PHP_METHOD(Bravo_Locale, _loadJsonFromLangDir);
PHP_METHOD(Bravo_Locale, _getServer);
PHP_METHOD(Bravo_Locale, _getBestQuality);
PHP_METHOD(Bravo_Locale, _getQualityHeader);

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_locale_getlanguages, 0, 0, IS_ARRAY, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_locale_getlanguages, 0, 0, IS_ARRAY, NULL, 0)
#endif
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_locale_getbestlanguage, 0, 0, IS_STRING, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_locale_getbestlanguage, 0, 0, IS_STRING, NULL, 0)
#endif
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_locale_loadjsonresource, 0, 2, IS_ARRAY, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_locale_loadjsonresource, 0, 2, IS_ARRAY, NULL, 0)
#endif
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, locale, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, locale)
#endif
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, appLangDir, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, appLangDir)
#endif
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, optionalLangDir, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, optionalLangDir)
#endif
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_locale__loadjsonfromlangdir, 0, 1, IS_ARRAY, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_locale__loadjsonfromlangdir, 0, 1, IS_ARRAY, NULL, 0)
#endif
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, localeDir, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, localeDir)
#endif
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_locale__getserver, 0, 1, IS_STRING, 1)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_locale__getserver, 0, 1, IS_STRING, NULL, 1)
#endif
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, name)
#endif
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_locale__getbestquality, 0, 2, IS_STRING, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_locale__getbestquality, 0, 2, IS_STRING, NULL, 0)
#endif
	ZEND_ARG_ARRAY_INFO(0, qualityParts, 0)
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, name)
#endif
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_locale__getqualityheader, 0, 2, IS_ARRAY, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_locale__getqualityheader, 0, 2, IS_ARRAY, NULL, 0)
#endif
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, serverIndex, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, serverIndex)
#endif
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
#else
	ZEND_ARG_INFO(0, name)
#endif
ZEND_END_ARG_INFO()

ZEPHIR_INIT_FUNCS(bravo_locale_method_entry) {
	PHP_ME(Bravo_Locale, getLanguages, arginfo_bravo_locale_getlanguages, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(Bravo_Locale, getBestLanguage, arginfo_bravo_locale_getbestlanguage, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(Bravo_Locale, loadJsonResource, arginfo_bravo_locale_loadjsonresource, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(Bravo_Locale, _loadJsonFromLangDir, arginfo_bravo_locale__loadjsonfromlangdir, ZEND_ACC_PROTECTED|ZEND_ACC_STATIC)
	PHP_ME(Bravo_Locale, _getServer, arginfo_bravo_locale__getserver, ZEND_ACC_PROTECTED|ZEND_ACC_FINAL|ZEND_ACC_STATIC)
	PHP_ME(Bravo_Locale, _getBestQuality, arginfo_bravo_locale__getbestquality, ZEND_ACC_PROTECTED|ZEND_ACC_FINAL|ZEND_ACC_STATIC)
	PHP_ME(Bravo_Locale, _getQualityHeader, arginfo_bravo_locale__getqualityheader, ZEND_ACC_PROTECTED|ZEND_ACC_FINAL|ZEND_ACC_STATIC)
	PHP_FE_END
};
