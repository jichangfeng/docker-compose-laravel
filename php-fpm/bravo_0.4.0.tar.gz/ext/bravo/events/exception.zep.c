
#ifdef HAVE_CONFIG_H
#include "../../ext_config.h"
#endif

#include <php.h>
#include "../../php_ext.h"
#include "../../ext.h"

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/main.h"


/**
 * Bravo\Events\Exception
 *
 * Exceptions thrown in Bravo\Events will use this class
 */
ZEPHIR_INIT_CLASS(Bravo_Events_Exception) {

	ZEPHIR_REGISTER_CLASS_EX(Bravo\\Events, Exception, bravo, events_exception, bravo_exception_ce, NULL, 0);

	return SUCCESS;

}

