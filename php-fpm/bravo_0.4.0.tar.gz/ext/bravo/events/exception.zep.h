
extern zend_class_entry *bravo_events_exception_ce;

ZEPHIR_INIT_CLASS(Bravo_Events_Exception);

