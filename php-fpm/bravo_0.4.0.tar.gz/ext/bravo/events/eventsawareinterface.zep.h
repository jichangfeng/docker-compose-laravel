
extern zend_class_entry *bravo_events_eventsawareinterface_ce;

ZEPHIR_INIT_CLASS(Bravo_Events_EventsAwareInterface);

ZEND_BEGIN_ARG_INFO_EX(arginfo_bravo_events_eventsawareinterface_seteventsmanager, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, eventsManager, Bravo\\Events\\ManagerInterface, 0)
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(arginfo_bravo_events_eventsawareinterface_geteventsmanager, 0, 0, Bravo\\Events\\ManagerInterface, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_events_eventsawareinterface_geteventsmanager, 0, 0, IS_OBJECT, "Bravo\\Events\\ManagerInterface", 0)
#endif
ZEND_END_ARG_INFO()

ZEPHIR_INIT_FUNCS(bravo_events_eventsawareinterface_method_entry) {
	PHP_ABSTRACT_ME(Bravo_Events_EventsAwareInterface, setEventsManager, arginfo_bravo_events_eventsawareinterface_seteventsmanager)
	PHP_ABSTRACT_ME(Bravo_Events_EventsAwareInterface, getEventsManager, arginfo_bravo_events_eventsawareinterface_geteventsmanager)
	PHP_FE_END
};
