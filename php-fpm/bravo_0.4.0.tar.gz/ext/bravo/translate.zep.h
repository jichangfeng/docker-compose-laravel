
extern zend_class_entry *bravo_translate_ce;

ZEPHIR_INIT_CLASS(Bravo_Translate);

