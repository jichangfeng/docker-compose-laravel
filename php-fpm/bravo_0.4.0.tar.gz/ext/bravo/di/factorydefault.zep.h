
extern zend_class_entry *bravo_di_factorydefault_ce;

ZEPHIR_INIT_CLASS(Bravo_Di_FactoryDefault);

PHP_METHOD(Bravo_Di_FactoryDefault, __construct);

ZEPHIR_INIT_FUNCS(bravo_di_factorydefault_method_entry) {
	PHP_ME(Bravo_Di_FactoryDefault, __construct, NULL, ZEND_ACC_PUBLIC|ZEND_ACC_CTOR)
	PHP_FE_END
};
