
#ifdef HAVE_CONFIG_H
#include "../../ext_config.h"
#endif

#include <php.h>
#include "../../php_ext.h"
#include "../../ext.h"

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/main.h"
#include "kernel/fcall.h"
#include "kernel/memory.h"
#include "kernel/array.h"
#include "kernel/object.h"


/**
 * Bravo\Di\FactoryDefault
 *
 * This is a variant of the standard Bravo\Di. By default it automatically
 * registers all the services provided by the framework. Thanks to this, the developer does not need
 * to register each service individually providing a full stack framework
 */
ZEPHIR_INIT_CLASS(Bravo_Di_FactoryDefault) {

	ZEPHIR_REGISTER_CLASS_EX(Bravo\\Di, FactoryDefault, bravo, di_factorydefault, bravo_di_ce, bravo_di_factorydefault_method_entry, 0);

	return SUCCESS;

}

/**
 * Bravo\Di\FactoryDefault constructor
 */
PHP_METHOD(Bravo_Di_FactoryDefault, __construct) {

	zval _2, _3, _4, _5;
	zval _1;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_0 = NULL;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&_4);
	ZVAL_UNDEF(&_5);

	ZEPHIR_MM_GROW();

	ZEPHIR_CALL_PARENT(NULL, bravo_di_factorydefault_ce, getThis(), "__construct", &_0, 0);
	zephir_check_call_status();
	ZEPHIR_INIT_VAR(&_1);
	zephir_create_array(&_1, 1, 0 TSRMLS_CC);
	ZEPHIR_INIT_VAR(&_2);
	object_init_ex(&_2, bravo_di_service_ce);
	ZEPHIR_INIT_VAR(&_3);
	ZVAL_STRING(&_3, "eventsManager");
	ZEPHIR_INIT_VAR(&_4);
	ZVAL_STRING(&_4, "Bravo\\Events\\Manager");
	ZVAL_BOOL(&_5, 1);
	ZEPHIR_CALL_METHOD(NULL, &_2, "__construct", NULL, 1, &_3, &_4, &_5);
	zephir_check_call_status();
	zephir_array_update_string(&_1, SL("eventsManager"), &_2, PH_COPY | PH_SEPARATE);
	zephir_update_property_zval(this_ptr, SL("_services"), &_1);
	ZEPHIR_MM_RESTORE();

}

