
extern zend_class_entry *bravo_di_injectionawareinterface_ce;

ZEPHIR_INIT_CLASS(Bravo_Di_InjectionAwareInterface);

ZEND_BEGIN_ARG_INFO_EX(arginfo_bravo_di_injectionawareinterface_setdi, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, dependencyInjector, Bravo\\DiInterface, 0)
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(arginfo_bravo_di_injectionawareinterface_getdi, 0, 0, Bravo\\DiInterface, 1)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_injectionawareinterface_getdi, 0, 0, IS_OBJECT, "Bravo\\DiInterface", 1)
#endif
ZEND_END_ARG_INFO()

ZEPHIR_INIT_FUNCS(bravo_di_injectionawareinterface_method_entry) {
	PHP_ABSTRACT_ME(Bravo_Di_InjectionAwareInterface, setDI, arginfo_bravo_di_injectionawareinterface_setdi)
	PHP_ABSTRACT_ME(Bravo_Di_InjectionAwareInterface, getDI, arginfo_bravo_di_injectionawareinterface_getdi)
	PHP_FE_END
};
