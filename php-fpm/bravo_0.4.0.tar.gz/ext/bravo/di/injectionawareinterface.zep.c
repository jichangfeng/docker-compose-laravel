
#ifdef HAVE_CONFIG_H
#include "../../ext_config.h"
#endif

#include <php.h>
#include "../../php_ext.h"
#include "../../ext.h"

#include <Zend/zend_exceptions.h>

#include "kernel/main.h"


/**
 * Bravo\Di\InjectionAwareInterface
 *
 * This interface must be implemented in those classes that uses internally the Bravo\Di that creates them
 */
ZEPHIR_INIT_CLASS(Bravo_Di_InjectionAwareInterface) {

	ZEPHIR_REGISTER_INTERFACE(Bravo\\Di, InjectionAwareInterface, bravo, di_injectionawareinterface, bravo_di_injectionawareinterface_method_entry);

	return SUCCESS;

}

/**
 * Sets the dependency injector
 */
ZEPHIR_DOC_METHOD(Bravo_Di_InjectionAwareInterface, setDI);

/**
 * Returns the internal dependency injector
 */
ZEPHIR_DOC_METHOD(Bravo_Di_InjectionAwareInterface, getDI);

