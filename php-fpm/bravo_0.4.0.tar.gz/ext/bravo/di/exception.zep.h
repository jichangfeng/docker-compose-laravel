
extern zend_class_entry *bravo_di_exception_ce;

ZEPHIR_INIT_CLASS(Bravo_Di_Exception);

