
extern zend_class_entry *bravo_di_service_builder_ce;

ZEPHIR_INIT_CLASS(Bravo_Di_Service_Builder);

PHP_METHOD(Bravo_Di_Service_Builder, _buildParameter);
PHP_METHOD(Bravo_Di_Service_Builder, _buildParameters);
PHP_METHOD(Bravo_Di_Service_Builder, build);

ZEND_BEGIN_ARG_INFO_EX(arginfo_bravo_di_service_builder__buildparameter, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, dependencyInjector, Bravo\\DiInterface, 0)
#if PHP_VERSION_ID >= 70200
	ZEND_ARG_TYPE_INFO(0, position, IS_LONG, 0)
#else
	ZEND_ARG_INFO(0, position)
#endif
	ZEND_ARG_ARRAY_INFO(0, argument, 0)
ZEND_END_ARG_INFO()

#if PHP_VERSION_ID >= 70200
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_service_builder__buildparameters, 0, 2, IS_ARRAY, 0)
#else
ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_bravo_di_service_builder__buildparameters, 0, 2, IS_ARRAY, NULL, 0)
#endif
	ZEND_ARG_OBJ_INFO(0, dependencyInjector, Bravo\\DiInterface, 0)
	ZEND_ARG_ARRAY_INFO(0, arguments, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_bravo_di_service_builder_build, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, dependencyInjector, Bravo\\DiInterface, 0)
	ZEND_ARG_ARRAY_INFO(0, definition, 0)
	ZEND_ARG_INFO(0, parameters)
ZEND_END_ARG_INFO()

ZEPHIR_INIT_FUNCS(bravo_di_service_builder_method_entry) {
	PHP_ME(Bravo_Di_Service_Builder, _buildParameter, arginfo_bravo_di_service_builder__buildparameter, ZEND_ACC_PRIVATE)
	PHP_ME(Bravo_Di_Service_Builder, _buildParameters, arginfo_bravo_di_service_builder__buildparameters, ZEND_ACC_PRIVATE)
	PHP_ME(Bravo_Di_Service_Builder, build, arginfo_bravo_di_service_builder_build, ZEND_ACC_PUBLIC)
	PHP_FE_END
};
