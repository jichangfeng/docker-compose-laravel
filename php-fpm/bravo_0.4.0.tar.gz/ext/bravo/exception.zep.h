
extern zend_class_entry *bravo_exception_ce;

ZEPHIR_INIT_CLASS(Bravo_Exception);

