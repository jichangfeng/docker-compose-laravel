
/* This file was generated automatically by Zephir do not modify it! */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <php.h>

#include "php_ext.h"
#include "bravo.h"

#include <ext/standard/info.h>

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/globals.h"
#include "kernel/main.h"
#include "kernel/fcall.h"
#include "kernel/memory.h"



zend_class_entry *bravo_diinterface_ce;
zend_class_entry *bravo_translate_adapterinterface_ce;
zend_class_entry *bravo_translate_interpolatorinterface_ce;
zend_class_entry *bravo_di_injectionawareinterface_ce;
zend_class_entry *bravo_di_serviceinterface_ce;
zend_class_entry *bravo_events_eventinterface_ce;
zend_class_entry *bravo_events_eventsawareinterface_ce;
zend_class_entry *bravo_events_managerinterface_ce;
zend_class_entry *bravo_di_serviceproviderinterface_ce;
zend_class_entry *bravo_exception_ce;
zend_class_entry *bravo_di_ce;
zend_class_entry *bravo_translate_adapter_ce;
zend_class_entry *bravo_di_exception_ce;
zend_class_entry *bravo_di_factorydefault_ce;
zend_class_entry *bravo_di_injectable_ce;
zend_class_entry *bravo_di_service_builder_ce;
zend_class_entry *bravo_di_service_ce;
zend_class_entry *bravo_events_event_ce;
zend_class_entry *bravo_events_exception_ce;
zend_class_entry *bravo_events_manager_ce;
zend_class_entry *bravo_locale_ce;
zend_class_entry *bravo_translate_adapter_nativearray_ce;
zend_class_entry *bravo_translate_ce;
zend_class_entry *bravo_translate_exception_ce;
zend_class_entry *bravo_translate_interpolator_associativearray_ce;
zend_class_entry *bravo_translate_interpolator_indexedarray_ce;

ZEND_DECLARE_MODULE_GLOBALS(bravo)

PHP_INI_BEGIN()
	
PHP_INI_END()

static PHP_MINIT_FUNCTION(bravo)
{
	REGISTER_INI_ENTRIES();
	zephir_module_init();
	ZEPHIR_INIT(Bravo_DiInterface);
	ZEPHIR_INIT(Bravo_Translate_AdapterInterface);
	ZEPHIR_INIT(Bravo_Translate_InterpolatorInterface);
	ZEPHIR_INIT(Bravo_Di_InjectionAwareInterface);
	ZEPHIR_INIT(Bravo_Di_ServiceInterface);
	ZEPHIR_INIT(Bravo_Events_EventInterface);
	ZEPHIR_INIT(Bravo_Events_EventsAwareInterface);
	ZEPHIR_INIT(Bravo_Events_ManagerInterface);
	ZEPHIR_INIT(Bravo_Di_ServiceProviderInterface);
	ZEPHIR_INIT(Bravo_Exception);
	ZEPHIR_INIT(Bravo_Di);
	ZEPHIR_INIT(Bravo_Translate_Adapter);
	ZEPHIR_INIT(Bravo_Di_Exception);
	ZEPHIR_INIT(Bravo_Di_FactoryDefault);
	ZEPHIR_INIT(Bravo_Di_Injectable);
	ZEPHIR_INIT(Bravo_Di_Service);
	ZEPHIR_INIT(Bravo_Di_Service_Builder);
	ZEPHIR_INIT(Bravo_Events_Event);
	ZEPHIR_INIT(Bravo_Events_Exception);
	ZEPHIR_INIT(Bravo_Events_Manager);
	ZEPHIR_INIT(Bravo_Locale);
	ZEPHIR_INIT(Bravo_Translate);
	ZEPHIR_INIT(Bravo_Translate_Adapter_NativeArray);
	ZEPHIR_INIT(Bravo_Translate_Exception);
	ZEPHIR_INIT(Bravo_Translate_Interpolator_AssociativeArray);
	ZEPHIR_INIT(Bravo_Translate_Interpolator_IndexedArray);
	
	return SUCCESS;
}

#ifndef ZEPHIR_RELEASE
static PHP_MSHUTDOWN_FUNCTION(bravo)
{
	
	zephir_deinitialize_memory(TSRMLS_C);
	UNREGISTER_INI_ENTRIES();
	return SUCCESS;
}
#endif

/**
 * Initialize globals on each request or each thread started
 */
static void php_zephir_init_globals(zend_bravo_globals *bravo_globals TSRMLS_DC)
{
	bravo_globals->initialized = 0;

	/* Cache Enabled */
	bravo_globals->cache_enabled = 1;

	/* Recursive Lock */
	bravo_globals->recursive_lock = 0;

	/* Static cache */
	memset(bravo_globals->scache, '\0', sizeof(zephir_fcall_cache_entry*) * ZEPHIR_MAX_CACHE_SLOTS);

	
	
}

/**
 * Initialize globals only on each thread started
 */
static void php_zephir_init_module_globals(zend_bravo_globals *bravo_globals TSRMLS_DC)
{
	
}

static PHP_RINIT_FUNCTION(bravo)
{
	zend_bravo_globals *bravo_globals_ptr;
#ifdef ZTS
	tsrm_ls = ts_resource(0);
#endif
	bravo_globals_ptr = ZEPHIR_VGLOBAL;

	php_zephir_init_globals(bravo_globals_ptr TSRMLS_CC);
	zephir_initialize_memory(bravo_globals_ptr TSRMLS_CC);

	
	return SUCCESS;
}

static PHP_RSHUTDOWN_FUNCTION(bravo)
{
	
	zephir_deinitialize_memory(TSRMLS_C);
	return SUCCESS;
}



static PHP_MINFO_FUNCTION(bravo)
{
	php_info_print_box_start(0);
	php_printf("%s", PHP_BRAVO_DESCRIPTION);
	php_info_print_box_end();

	php_info_print_table_start();
	php_info_print_table_header(2, PHP_BRAVO_NAME, "enabled");
	php_info_print_table_row(2, "Author", PHP_BRAVO_AUTHOR);
	php_info_print_table_row(2, "Version", PHP_BRAVO_VERSION);
	php_info_print_table_row(2, "Build Date", __DATE__ " " __TIME__ );
	php_info_print_table_row(2, "Powered by Zephir", "Version " PHP_BRAVO_ZEPVERSION);
	php_info_print_table_end();
	
	DISPLAY_INI_ENTRIES();
}

static PHP_GINIT_FUNCTION(bravo)
{
	php_zephir_init_globals(bravo_globals TSRMLS_CC);
	php_zephir_init_module_globals(bravo_globals TSRMLS_CC);
}

static PHP_GSHUTDOWN_FUNCTION(bravo)
{
	
}


zend_function_entry php_bravo_functions[] = {
	ZEND_FE_END

};

static const zend_module_dep php_bravo_deps[] = {
	
	ZEND_MOD_END
};

zend_module_entry bravo_module_entry = {
	STANDARD_MODULE_HEADER_EX,
	NULL,
	php_bravo_deps,
	PHP_BRAVO_EXTNAME,
	php_bravo_functions,
	PHP_MINIT(bravo),
#ifndef ZEPHIR_RELEASE
	PHP_MSHUTDOWN(bravo),
#else
	NULL,
#endif
	PHP_RINIT(bravo),
	PHP_RSHUTDOWN(bravo),
	PHP_MINFO(bravo),
	PHP_BRAVO_VERSION,
	ZEND_MODULE_GLOBALS(bravo),
	PHP_GINIT(bravo),
	PHP_GSHUTDOWN(bravo),
#ifdef ZEPHIR_POST_REQUEST
	PHP_PRSHUTDOWN(bravo),
#else
	NULL,
#endif
	STANDARD_MODULE_PROPERTIES_EX
};

#ifdef COMPILE_DL_BRAVO
ZEND_GET_MODULE(bravo)
#endif
