
/* This file was generated automatically by Zephir do not modify it! */

#ifndef PHP_BRAVO_H
#define PHP_BRAVO_H 1

#ifdef PHP_WIN32
#define ZEPHIR_RELEASE 1
#endif

#include "kernel/globals.h"

#define PHP_BRAVO_NAME        "bravo"
#define PHP_BRAVO_VERSION     "0.4.0"
#define PHP_BRAVO_EXTNAME     "bravo"
#define PHP_BRAVO_AUTHOR      "Rack Lin"
#define PHP_BRAVO_ZEPVERSION  "0.12.4-b386980"
#define PHP_BRAVO_DESCRIPTION "The essential components for ci/yaf web frameworks,delivered as C-extension."



ZEND_BEGIN_MODULE_GLOBALS(bravo)

	int initialized;

	/** Function cache */
	HashTable *fcache;

	zephir_fcall_cache_entry *scache[ZEPHIR_MAX_CACHE_SLOTS];

	/* Cache enabled */
	unsigned int cache_enabled;

	/* Max recursion control */
	unsigned int recursive_lock;

	
ZEND_END_MODULE_GLOBALS(bravo)

#ifdef ZTS
#include "TSRM.h"
#endif

ZEND_EXTERN_MODULE_GLOBALS(bravo)

#ifdef ZTS
	#define ZEPHIR_GLOBAL(v) ZEND_MODULE_GLOBALS_ACCESSOR(bravo, v)
#else
	#define ZEPHIR_GLOBAL(v) (bravo_globals.v)
#endif

#ifdef ZTS
	void ***tsrm_ls;
	#define ZEPHIR_VGLOBAL ((zend_bravo_globals *) (*((void ***) tsrm_get_ls_cache()))[TSRM_UNSHUFFLE_RSRC_ID(bravo_globals_id)])
#else
	#define ZEPHIR_VGLOBAL &(bravo_globals)
#endif

#define ZEPHIR_API ZEND_API

#define zephir_globals_def bravo_globals
#define zend_zephir_globals_def zend_bravo_globals

extern zend_module_entry bravo_module_entry;
#define phpext_bravo_ptr &bravo_module_entry

#endif
