
/* This file was generated automatically by Zephir do not modify it! */

#ifndef ZEPHIR_CLASS_ENTRIES_H
#define ZEPHIR_CLASS_ENTRIES_H

#include "bravo/exception.zep.h"
#include "bravo/diinterface.zep.h"
#include "bravo/translate/adapterinterface.zep.h"
#include "bravo/translate/interpolatorinterface.zep.h"
#include "bravo/di.zep.h"
#include "bravo/di/injectionawareinterface.zep.h"
#include "bravo/di/serviceinterface.zep.h"
#include "bravo/events/eventinterface.zep.h"
#include "bravo/events/eventsawareinterface.zep.h"
#include "bravo/events/managerinterface.zep.h"
#include "bravo/translate/adapter.zep.h"
#include "bravo/di/exception.zep.h"
#include "bravo/di/factorydefault.zep.h"
#include "bravo/di/injectable.zep.h"
#include "bravo/di/service.zep.h"
#include "bravo/di/service/builder.zep.h"
#include "bravo/di/serviceproviderinterface.zep.h"
#include "bravo/events/event.zep.h"
#include "bravo/events/exception.zep.h"
#include "bravo/events/manager.zep.h"
#include "bravo/locale.zep.h"
#include "bravo/translate.zep.h"
#include "bravo/translate/adapter/nativearray.zep.h"
#include "bravo/translate/exception.zep.h"
#include "bravo/translate/interpolator/associativearray.zep.h"
#include "bravo/translate/interpolator/indexedarray.zep.h"

#endif